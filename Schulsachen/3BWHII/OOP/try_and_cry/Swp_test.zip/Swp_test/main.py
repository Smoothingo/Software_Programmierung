from terminal_handler.in_out import * 
import numpy as np

n= int_input()

curr = 2
while curr <= n:
    is_p = True
    d = 2
    if d >= np.sqrt(curr):
        if curr % d == 0:
            is_p = False
            break
    else:
        if is_p:
            print(curr)
        else:
            curr += 1
        break

print("Programmende")

    
