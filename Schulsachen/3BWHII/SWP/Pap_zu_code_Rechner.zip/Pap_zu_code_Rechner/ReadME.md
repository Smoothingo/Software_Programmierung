# Aufgabe 3 - Code optimieren

# Von Markus Kattner

# https://github.com/Smoothingo
