from module import logic

if __name__ == "__main__":
    logic.big_boy()
