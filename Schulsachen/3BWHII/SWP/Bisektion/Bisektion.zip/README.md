# Dependencies die benötigt werden
### pip install matplotlib, numpy 

### typing und json auch aber diese sind in standart python enthalten
---------------------------------------------------------------------
# Wie nutzt man es
entweder im cmd mit:
cd "pfad\zum\projekt\folder"
python3 main.py

oder in einer belibiegen IDE folder öffnen und auf python run drücken

Je nach Auswahl die benötigten parameter eingeben. Linke grenze = a Rechte Grenze = b falls das hilft
Bei newton wird nur 1 sache benötigt. entweder b oder (a+b)/2 je nach Sinn der Berechnung

Bei Polynom ist die Formel von der Angabe schon drinnen. Um auf 3,4567... zu kommen einfach die naheliegenden Grenzen eingeben. 
In dem Fall bsp: Intervall = (3,4)

Bei Kettenlinie einfach die länge des ganzen und die differenz y eingeben. also wie weit das seil nach unten hängt. 

# 🔧 Features

### Automatische Intervall-Schätzung bei Kettenlinie

### Dynamische Funktionseingabe via eval() (z.B. x**2 - 25)

### Visualisierung der Iterationsschritte

## Liebe Grüẞe Kattner
## Viel Spaẞ

### Erreichbar unter mkattner@student.tgm.ac.at oder smoothingo@proton.me für jegliche Art von Fragen :) 
