from fibo_module import fibo_ask
fibo_ask()
