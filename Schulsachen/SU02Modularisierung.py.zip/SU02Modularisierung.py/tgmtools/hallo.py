print("Hello World")

def Hello_World():
    print("Hello World!")